# 加密货币永续合约量化研究

更新时间：2026-10-15（Asia/Shanghai）。

## 已确认需求

币安 USDT 本位永续，BTC／ETH，多空，逐仓，关闭自动追加保证金，同币先平仓再反向开仓。初始模拟本金 100 美元，累计亏损 50 美元为最终承受边界，账户有效总杠杆最高 10 倍。先检验扣费后的稳健收益，不设固定收益数值。以前提供的 AGENTS.md 指令不再适用。

## 当前状态

首轮 R001-v1 参数保持不变。已实现配置／仓位预算、版本化样本下载与校验、资金费历史价格近似，以及线性逐仓保证金／强平公式。前轮风险模块 8 项检查有历史通过记录；本轮新数据 6 项、保证金 5 项及准备度用例 1 项通过。没有共享账户引擎、策略回测或盈利结果。

已下载 8 个原始归档并全部核对官方 CHECKSUM：两币 2023-01-01 成交价／标记价、2023-01 资金费，以及 2022-12-31 标记价边界。主样本分钟线各 1440 根，资金费各 93 个事件与公开 REST 完全一致。完整开发期未下载；未读取或评价 2026 候选保留区间，没有连接交易账户。

当前快照中的最小开仓名义金额：BTC 50 USDT、ETH 20 USDT。采用首轮风险预算时可能拒绝部分信号，不能提高风险预算去凑最低订单；规则快照尚未冻结为历史适用规则。

## 文件入口

- [需求与验收](docs/需求与验收.md)：用户要求、已固定的研究默认值和剩余证据缺口。
- [第一轮实验方案](docs/第一轮实验方案.md)：风险、时间范围、两个机制、成本、有限账户预算及筛选口径。
- [研究配置](configs/first_round.toml)：参数集中入口；研究默认值不是优化结果。
- [系统设计](docs/系统设计草案.md)：模块、合约账本、订单与风险职责。
- [小样本验收与资金费估值政策](docs/小样本数据验收.md)：真实数据证据及 DATA-001-v1 近似。
- [逐仓保证金计算说明](docs/逐仓保证金计算说明.md)：公式、输入输出、已测试范围及历史规则缺口。
- [规则核对记录](docs/规则核对记录.md)：文档与实时来源证据，明确未取得的保证金档位。
- [前期调研](docs/调研参考.md)：背景资料，不替代本轮配置。
- [来源探测结果](artifacts/setup/source_probe.json)、[当前规则快照](artifacts/rules/exchange_rules.json)、[本轮交付清单](artifacts/setup/design_manifest.json)。

## 当前可用命令

要求 Python 3.11+；本轮实际使用 Python 3.12.10，无第三方依赖。先进入项目目录：

```powershell
Set-Location -LiteralPath 'D:\量化'
python -B run.py check-config
python -B run.py size-preview --leverage-cap 10
python -B run.py check-readiness
python -B -m unittest discover -s tests -v
```

`check-config` 只检查配置约束。`size-preview` 用固定的合成价格和合成订单规则演示数量预算，不是 BTC／ETH 真实行情或下单建议，也不检查强平。`check-readiness` 当前应返回 ready=false 和退出码 2，说明数据、账本和强平模型尚未完成。

```powershell
python -B scripts/probe_sources.py
```

来源探测只 GET 当前公开规则，对 2023 归档作 HEAD 检查，不读取历史价格记录。新版每次写入 artifacts/setup/source_probes/ 下独立目录；初始规则与报告保留未变。样本下载器按内容哈希保存原始数据和校验和，另建唯一运行清单。尚无完整开发期下载、训练、策略回测或实盘命令。

## 接手后的下一行动

先把已验证的样本路径、校验和及字段检查推广到完整热身／开发期，建立按区间覆盖的清单；随后实现共享逐仓账本与资金费事件消费。2026 候选保留区间继续锁定。小样本不代表整个开发期已通过。

历史保证金档位与强平收费仍缺证据：公式模块已完成算术检查，但没有把合成档位当作实际规则。正式回测前需取得证据或明确冻结代理口径及局限。准备度仍为 false；源码与原始证据已保存，本轮没有后台任务。

## 本轮样本命令

```powershell
python -B scripts/download_sample.py
python -B scripts/download_funding_sample.py
python -B scripts/download_boundary_sample.py
python -B scripts/audit_sample.py artifacts/data/manifests/SAMPLE-20261015T061308Z-a752e6fa.json artifacts/data/manifests/FUNDING-20261015T061607Z-330c77b5.json
python -B scripts/audit_funding_proxy.py artifacts/data/manifests/SAMPLE-20261015T061308Z-a752e6fa.json artifacts/data/manifests/BOUNDARY-20261015T062421Z-17c4a437.json
```

前三条仅下载固定日期的小样本，新运行产生新清单；已有原始文件可直接用后两条本地审计，无需重复下载。新增命令不执行任何交易。

资金费估值补充以 [DATA-001-v1](configs/data_policy.toml) 为准：真实结算标记价优先，历史字段缺失时使用结算前已闭合分钟标记价，年龄不得超过 60 秒。当前样本 186 个精确结算价均为空；首日六个事件已验证近似价格可得，不能称精确结算复现。

本数据阶段的文件哈希与检查证据见 [DATA-001-v1 交付清单](artifacts/setup/DATA-001-v1_delivery.json)。
