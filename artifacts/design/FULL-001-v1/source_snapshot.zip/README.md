# 加密货币永续合约量化研究

更新时间：2026-10-15（Asia/Shanghai）。

## 已确认需求

币安 USDT 本位永续，BTC／ETH，多空，逐仓，关闭自动追加保证金，同币先平仓再反向开仓。初始模拟本金 100 美元，累计亏损 50 美元为最终承受边界，账户有效总杠杆最高 10 倍。先检验扣费后的稳健收益，不设固定收益数值。以前提供的 AGENTS.md 指令不再适用。

## 当前状态

首轮 R001-v1 与 DATA-001-v1 输入保持不变。完整热身／开发期数据已准备并通过来源、结构、整月覆盖、跨月和资金费估值核对：228 份月包，6,664,320 根分钟记录；开发期 6,576 次资金费，其中 4,756 次有 API 结算标记价、1,820 次使用已约定的闭合分钟代理，最大年龄 29 毫秒。四份原始月包的缺口通过官方日包或 REST 实际记录补齐，原始失败证据全部保留。

共享模拟账本已实现预留、部分成交、取消、逐仓钱包、手续费、资金费、减仓平仓、账户保护和 SQLite 日志重启核对。仍没有策略执行器或有效的策略收益结果。历史交易过滤条件、保证金档位与强平执行证据尚未完成，execution_ready 仍为 false。2026 候选保留区间继续锁定，未接入交易账户。

当前快照中的最小开仓名义金额：BTC 50 USDT、ETH 20 USDT。这是当前规则快照，尚未冻结为历史适用规则；不能为凑最低订单提高风险预算。

## 文件入口

- [完整开发期数据验收](docs/完整开发期数据验收.md)：全部数据、修复来源与估值边界。
- [共享账户账本](docs/共享账户账本.md)：资金守恒、部分成交、保护与重启。
- [需求与验收](docs/需求与验收.md)：用户要求、已固定的研究默认值和剩余证据缺口。
- [第一轮实验方案](docs/第一轮实验方案.md)：风险、时间范围、两个机制、成本、有限账户预算及筛选口径。
- [研究配置](configs/first_round.toml)：参数集中入口；研究默认值不是优化结果。
- [系统设计](docs/系统设计草案.md)：模块、合约账本、订单与风险职责。
- [小样本验收与资金费估值政策](docs/小样本数据验收.md)：真实数据证据及 DATA-001-v1 近似。
- [逐仓保证金计算说明](docs/逐仓保证金计算说明.md)：公式、输入输出、已测试范围及历史规则缺口。
- [规则核对记录](docs/规则核对记录.md)：文档与实时来源证据，明确未取得的保证金档位。
- [前期调研](docs/调研参考.md)：背景资料，不替代本轮配置。
- [来源探测结果](artifacts/setup/source_probe.json)、[当前规则快照](artifacts/rules/exchange_rules.json)、[本轮交付清单](artifacts/setup/design_manifest.json)。

## 当前可用命令

要求 Python 3.11+；本轮实际使用 Python 3.12.10，无第三方依赖。先进入项目目录：

```powershell
Set-Location -LiteralPath 'D:\量化'
python -B run.py check-config
python -B run.py size-preview --leverage-cap 10
python -B run.py check-readiness
python -B -m unittest discover -s tests -v
```

`check-config` 只检查配置约束。`size-preview` 用固定的合成价格和合成订单规则演示数量预算，不是 BTC／ETH 真实行情或下单建议，也不检查强平。`check-readiness` 当前应返回 ready=false 和退出码 2，说明策略执行器与历史强平证据尚未完成；冻结配置中的准备度字段不自动改写，当前数据验收状态见总入口清单。

```powershell
python -B scripts/probe_sources.py
```

来源探测只 GET 当前公开规则，对 2023 归档作 HEAD 检查，不读取历史价格记录。新版每次写入 artifacts/setup/source_probes/ 下独立目录；初始规则与报告保留未变。样本下载器按内容哈希保存原始数据和校验和，另建唯一运行清单。完整开发期准备与本地复查命令见下文；尚无策略回测或实盘命令。

## 接手后的下一行动

下一步实现按事件时间执行的模拟引擎，接入两个冻结机制，处理同分钟止损／强平／结算顺序与拒单。历史过滤条件、保证金档位、强平收费仍需取得证据，或另行明确冻结代理及局限；不能把合成测试档位当作真实规则。2026 候选保留区间继续锁定。

## 本轮样本命令

```powershell
python -B scripts/download_sample.py
python -B scripts/download_funding_sample.py
python -B scripts/download_boundary_sample.py
python -B scripts/audit_sample.py artifacts/data/manifests/SAMPLE-20261015T061308Z-a752e6fa.json artifacts/data/manifests/FUNDING-20261015T061607Z-330c77b5.json
python -B scripts/audit_funding_proxy.py artifacts/data/manifests/SAMPLE-20261015T061308Z-a752e6fa.json artifacts/data/manifests/BOUNDARY-20261015T062421Z-17c4a437.json
```

前三条仅下载固定日期的小样本，新运行产生新清单；已有原始文件可直接用后两条本地审计，无需重复下载。新增命令不执行任何交易。

资金费估值补充以 [DATA-001-v1](configs/data_policy.toml) 为准：真实结算标记价优先，历史字段缺失时使用结算前已闭合分钟标记价，年龄不得超过 60 秒。当前样本 186 个精确结算价均为空；首日六个事件已验证近似价格可得，不能称精确结算复现。

本数据阶段的文件哈希与检查证据见 [DATA-001-v1 交付清单](artifacts/setup/DATA-001-v1_delivery.json)。

## 本阶段完成记录

2026-10-15 本阶段已完成：完整开发期数据准备、四份缺口月包修复及共享账户账本。下载任务已结束，没有遗留后台任务。数据完整不代表已有盈利模型；仍需完成事件执行器与历史规则建模。

```powershell
python -B scripts/prepare_development.py
python -B scripts/reconcile_development.py artifacts/data/full_runs/DEVELOPMENT-20261015T063811Z-f5b56f9c/manifest.json
python -B scripts/verify_full_stage.py
python -B scripts/demo_ledger.py
```

前两条会访问公开历史接口并产生独立清单；第三条仅本地复核数据文件与新增模块检查。最后一条只产生明确标记的合成账目例子，例中盈亏不代表策略表现。阶段文件版本与证据见 [交付清单](artifacts/setup/FULL-001-v1_delivery.json)。

